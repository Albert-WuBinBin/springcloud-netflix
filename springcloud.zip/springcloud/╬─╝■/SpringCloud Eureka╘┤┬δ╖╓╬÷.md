# K8S学习

## 杂记：

### 1.**云服务IaaS、PaaS、SaaS**

IaaS、PaaS、SaaS简单的说都属于云计算服务，也就是云计算+服务。

我们对于云计算的概念，维基百科有以下定义：Cloud computing is a new form of Internet-based computing that provides shared computer processing resources and data to computers and other devices on demand. 

云计算就是一种按照需求通过Internet获取计算资源的形态。这些计算资源被包装成为服务，提供给用户。而提供这些服务的主体，我们称之为云服务供应商（Cloud Service Provider）。

按照NIST (National Institute of Standards and Technology，美国国家标准和技术研究院)的定义，云服务最主要的有三类：IaaS、PaaS、SaaS。

![img](D:\学习\springcloud\文件\k8s\云服务.jpg)

On Premises 本地部署

IaaS（Infrastructure as a service – 基础设施即服务）：用户可以在云服务提供商提供的基础设施上部署和运行任何软件，包括[操作系统](https://www.zhihu.com/search?q=操作系统&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A743669668})和应用软件。用户没有权限管理和访问底层的基础设施，如服务器、交换机、硬盘等，但是有权管理操作系统、存储内容，可以安装管理应用程序，甚至是有权管理网络组件。简单的说用户使用IaaS，有权管理操作系统之上的一切功能。我们常见的IaaS服务有虚拟机、虚拟网络、以及存储。

PaaS（Platform as a service – 平台即服务）：PaaS给用户提供的能力是使用由云服务提供商支持的编程语言、库、服务以及开发工具来创建、开发应用程序并部署在相关的基础设施上。用户无需管理底层的基础设施，包括网络、服务器，操作系统或者存储。他们只能控制部署在基础设施中操作系统上的应用程序，配置应用程序所托管的环境的可配置参数。常见的PaaS服务有数据库服务、web应用以及容器服务。成熟的PaaS服务会简化开发人员，提供完备的PC端和移动端软件开发套件（SDK），拥有丰富的开发环境（Inteli、Eclipse、VS等），完全可托管的数据库服务，可配置式的应用程序构建，支持多语言的开发，面向应用市场。

SaaS（Software as a Service – 软件即服务）：SaaS给用户提供的能力是使用在云基础架构上运行的云服务提供商的应用程序。可以通过轻量的客户端接口（诸如web浏览器（例如，基于web的电子邮件））或程序接口从各种客户端设备访问应用程序。 用户无需管理或控制底层云基础架构，包括网络，服务器，操作系统，存储甚至单独的应用程序功能，可能的例外是有限的用户特定应用程序配置设置。类似的服务有：各类的网盘(Dropbox、百度网盘等)，JIRA，GitLab等服务。而这些应用的提供者不仅仅是云服务提供商，还有众多的第三方提供商（ISV: independent software provider）。

这里借用汽车的例子对IaaS、PaaS、SaaS的解释进一步阐述三者的区别。假设你需要出去外出使用交通工具，我们有四种的方案：

On-premise方案： 

自己开车，需要维护汽车，是其安全工作。同时需要为车上保险，提供燃料。（服务器 + 操作系统/数据库 + 应用软件）

IaaS: 

从租车公司租一辆车，汽车的维修、安检都由租车公司承担。你只需要提供燃料（需要提供操作系统+应用软件）

PaaS: 

除了基础设施（汽车），还为你提供司机。类似出租车。只需要提供目的地，汽车的行驶和运行都有司机决定。（只需要提供应用软件）。

SaaS:

类似于做轨道交通， 一切都是由别人控制。只有较少的定制化功能。

目前主流的IaaS、PaaS和SaaS产品如下图所示：

![img](D:\学习\springcloud\文件\k8s\2.jpg)



额外补充FaaS。FaaS，Function as a Service，"功能即服务"（也译作“函数即服务”），是一种在无状态容器中运行的**事件驱动型计算执行模型**，这些功能将利用服务来管理服务器端逻辑和状态。 

它允许开发人员以功能的形式来构建、运行和管理这些应用包，无需维护自己的基础架构。

FaaS 是一种实现[无服务器计算](https://links.jianshu.com/go?to=https%3A%2F%2Fwww.redhat.com%2Fzh%2Ftopics%2Fcloud-native-apps%2Fwhat-is-serverless)的方法，藉此开发人员可以编写业务逻辑，然后在完全由平台管理的 Linux 容器中执行这些业务逻辑。

该平台通常位于云端，但模型正在扩展至包含内部部署和混合部署。

无服务器会对基础架构问题进行抽象处理，例如管理或置备服务器及开发人员的资源分配，并将其提供给平台，这样开发人员就可以专注于编写代码和实现业务价值。 可以参考：https://www.jianshu.com/p/bb7fc6d17616




除此之外，云计算目前主流的部署模式分为三类：

**私有云**（Private Cloud / On Premise）: 私有云是专为单个组织运营的云基础架构，管理的模式有内部管理，第三方管理，亦或是内部或外部托管。简单的讲，私有云就是通过自建或者租用场地的形式建立服务器机房或者数据中心。服务是面向私有网络或者VPN专有网络。企业拥有对服务器、数据硬盘的完全控制。因此安全性很高。

**公有云**（Public Cloud）：公有云服务面向公开网络暴露，服务可能也是免费的。由于网络对外公布，因此从安全层面上也是大不相同的。常见的公有云有AWS，Microsoft Azure，阿里云等。

**混合云**（Hybrid Cloud）：混合云是两个或多个云（私有云，社区云或公共云）的组合，它们保持不同的实体但绑定在一起，提供多个部署模型的好处。 混合云还意味着能够使用云资源连接搭配，托管和/或专用服务。比较常见的例子如数据公司，可能拥有很多数据，而这些数据因为合规性等原因只能放在私有环境，当需要大规模机器学习，对数据进行脱敏后使用公有云进行大规模学习。

### 2.微服务化之无状态化与容器化

https://www.cnblogs.com/163yun/p/10005994.html

### 3.Paxos算法原理与推导

#### Paxos是什么

> Paxos算法是基于**消息传递**且具有**高度容错特性**的**一致性算法**，是目前公认的解决**分布式一致性**问题**最有效**的算法之一。

Google Chubby的作者Mike Burrows说过这个世界上**只有一种**一致性算法，那就是Paxos，其它的算法都是**残次品**。

虽然Mike Burrows说得有点夸张，但是至少说明了Paxos算法的地位。然而，Paxos算法也因为晦涩难懂而臭名昭著。本文的目的就是带领大家深入浅出理解Paxos算法，不仅理解它的执行流程，还要理解算法的推导过程，作者是怎么一步步想到最终的方案的。只有理解了推导过程，才能深刻掌握该算法的精髓。而且理解推导过程对于我们的思维也是非常有帮助的，可能会给我们带来一些解决问题的思路，对我们有所启发。

#### 问题产生的背景

在常见的分布式系统中，总会发生诸如**机器宕机**或**网络异常**（包括消息的延迟、丢失、重复、乱序，还有网络分区）等情况。Paxos算法需要解决的问题就是如何在一个可能发生上述异常的分布式系统中，快速且正确地在集群内部对**某个数据的值**达成**一致**，并且保证不论发生以上任何异常，都不会破坏整个系统的一致性。

注：这里**某个数据的值**并不只是狭义上的某个数，它可以是一条日志，也可以是一条命令（command）。。。根据应用场景不同，**某个数据的值**有不同的含义。

![问题产生的背景](D:\学习\springcloud\文件\paxos\1.jpg)

#### 相关概念

在Paxos算法中，有三种角色：

- **Proposer**
- **Acceptor**
- **Learners**

在具体的实现中，一个进程可能**同时充当多种角色**。比如一个进程可能**既是Proposer又是Acceptor又是Learner**。

还有一个很重要的概念叫**提案（Proposal）**。最终要达成一致的value就在提案里。

**注：**

- **暂且**认为『**提案=value**』，即提案只包含value。在我们接下来的推导过程中会发现如果提案只包含value，会有问题，于是我们再对提案**重新设计**。
- **暂且**认为『**Proposer可以直接提出提案**』。在我们接下来的推导过程中会发现如果Proposer直接提出提案会有问题，需要增加一个学习提案的过程。

Proposer可以提出（propose）提案；Acceptor可以接受（accept）提案；如果某个提案被选定（chosen），那么该提案里的value就被选定了。

回到刚刚说的『对某个数据的值达成一致』，指的是Proposer、Acceptor、Learner都认为同一个value被选定（chosen）。那么，Proposer、Acceptor、Learner分别在什么情况下才能认为某个value被选定呢？

- Proposer：只要Proposer发的提案被Acceptor接受（刚开始先认为只需要一个Acceptor接受即可，在推导过程中会发现需要半数以上的Acceptor同意才行），Proposer就认为该提案里的value被选定了。
- Acceptor：只要Acceptor接受了某个提案，Acceptor就任务该提案里的value被选定了。
- Learner：Acceptor告诉Learner哪个value被选定，Learner就认为那个value被选定。

![相关概念](D:\学习\springcloud\文件\paxos\2.jpg)

#### 问题描述

假设有一组可以**提出（propose）value**（value在提案Proposal里）的**进程集合**。一个一致性算法需要保证提出的这么多value中，**只有一个**value被选定（chosen）。如果没有value被提出，就不应该有value被选定。如果一个value被选定，那么所有进程都应该能**学习（learn）**到这个被选定的value。对于一致性算法，**安全性（safaty）**要求如下：

- 只有被提出的value才能被选定。
- 只有一个value被选定，并且如果某个进程认为某个value被选定了，那么这个value必须是真的被选定的那个。

我们不去精确地定义其**活性（liveness）**要求。我们的目标是保证**最终有一个提出的value被选定**。当一个value被选定后，进程最终也能学习到这个value。

> Paxos的目标：保证最终有一个value会被选定，当value被选定后，进程最终也能获取到被选定的value。

假设不同角色之间可以通过发送消息来进行通信，那么：

- 每个角色以任意的速度执行，可能因出错而停止，也可能会重启。一个value被选定后，所有的角色可能失败然后重启，除非那些失败后重启的角色能记录某些信息，否则等他们重启后无法确定被选定的值。
- 消息在传递过程中可能出现任意时长的延迟，可能会重复，也可能丢失。但是消息不会被损坏，即消息内容不会被篡改（拜占庭将军问题）。

#### 推导过程

##### 最简单的方案——只有一个Acceptor

假设只有一个Acceptor（可以有多个Proposer），只要Acceptor接受它收到的第一个提案，则该提案被选定，该提案里的value就是被选定的value。这样就保证只有一个value会被选定。

但是，如果这个唯一的Acceptor宕机了，那么整个系统就**无法工作**了！

因此，必须要有**多个Acceptor**！

![只有一个Acceptor](D:\学习\springcloud\文件\paxos\3.jpg)

##### 多个Acceptor

多个Acceptor的情况如下图。那么，如何保证在多个Proposer和多个Acceptor的情况下选定一个value呢？

![多个Acceptor](D:\学习\springcloud\文件\paxos\4.jpg)

下面开始寻找解决方案。

如果我们希望即使只有一个Proposer提出了一个value，该value也最终被选定。

那么，就得到下面的约束：

> P1：一个Acceptor必须接受它收到的第一个提案。

但是，这又会引出另一个问题：如果每个Proposer分别提出不同的value，发给不同的Acceptor。根据P1，Acceptor分别接受自己收到的value，就导致不同的value被选定。出现了不一致。如下图：

![幻灯片08.png](D:\学习\springcloud\文件\paxos\5.jpg)

刚刚是因为『一个提案只要被一个Acceptor接受，则该提案的value就被选定了』才导致了出现上面不一致的问题。因此，我们需要加一个规定：

> 规定：一个提案被选定需要被**半数以上**的Acceptor接受

这个规定又暗示了：『一个Acceptor必须能够接受不止一个提案！』不然可能导致最终没有value被选定。比如上图的情况。v1、v2、v3都没有被选定，因为它们都只被一个Acceptor的接受。

最开始讲的『**提案=value**』已经不能满足需求了，于是重新设计提案，给每个提案加上一个提案编号，表示提案被提出的顺序。令『**提案=提案编号+value**』。

虽然允许多个提案被选定，但必须保证所有被选定的提案都具有相同的value值。否则又会出现不一致。

于是有了下面的约束：

> P2：如果某个value为v的提案被选定了，那么每个编号更高的被选定提案的value必须也是v。

一个提案只有被Acceptor接受才可能被选定，因此我们可以把P2约束改写成对Acceptor接受的提案的约束P2a。

> P2a：如果某个value为v的提案被选定了，那么每个编号更高的被Acceptor接受的提案的value必须也是v。

只要满足了P2a，就能满足P2。

但是，考虑如下的情况：假设总的有5个Acceptor。Proposer2提出[M1,V1]的提案，Acceptor2（半数以上）均接受了该提案，于是对于Acceptor2和Proposer2来讲，它们都认为V1被选定。Acceptor1刚刚从宕机状态恢复过来（之前Acceptor1没有收到过任何提案），此时Proposer1向Acceptor1发送了[M2,V2]的提案（V2≠V1且M2>M1），对于Acceptor1来讲，这是它收到的第一个提案。根据P1（一个Acceptor必须接受它收到的第一个提案。）,Acceptor1必须接受该提案！同时Acceptor1认为V2被选定。这就出现了两个问题：

1. Acceptor1认为V2被选定，Acceptor2~5和Proposer2认为V1被选定。出现了不一致。
2. V1被选定了，但是编号更高的被Acceptor1接受的提案[M2,V2]的value为V2，且V2≠V1。这就跟P2a（如果某个value为v的提案被选定了，那么每个编号更高的被Acceptor接受的提案的value必须也是v）矛盾了。

![幻灯片10.png](D:\学习\springcloud\文件\paxos\6.jpg)

所以我们要对P2a约束进行强化！

P2a是对Acceptor接受的提案约束，但其实提案是Proposer提出来的，所有我们可以对Proposer提出的提案进行约束。得到P2b：

> P2b：如果某个value为v的提案被选定了，那么之后任何Proposer提出的编号更高的提案的value必须也是v。

由P2b可以推出P2a进而推出P2。

那么，如何确保在某个value为v的提案被选定后，Proposer提出的编号更高的提案的value都是v呢？

只要满足P2c即可：

> P2c：对于任意的N和V，如果提案[N, V]被提出，那么存在一个半数以上的Acceptor组成的集合S，满足以下两个条件中的任意一个：

- S中每个Acceptor都没有接受过编号小于N的提案。
- S中Acceptor接受过的最大编号的提案的value为V。

##### Proposer生成提案

为了满足P2b，这里有个比较重要的思想：Proposer生成提案之前，应该先去**『学习』**已经被选定或者可能被选定的value，然后以该value作为自己提出的提案的value。如果没有value被选定，Proposer才可以自己决定value的值。这样才能达成一致。这个学习的阶段是通过一个**『Prepare请求』**实现的。

于是我们得到了如下的**提案生成算法**：

1. Proposer选择一个**新的提案编号N**，然后向**某个Acceptor集合**（半数以上）发送请求，要求该集合中的每个Acceptor做出如下响应（response）。
   (a) 向Proposer承诺保证**不再接受**任何编号**小于N的提案**。
   (b) 如果Acceptor已经接受过提案，那么就向Proposer响应**已经接受过**的编号小于N的**最大编号的提案**。

   我们将该请求称为**编号为N**的**Prepare请求**。

2. 如果Proposer收到了**半数以上**的Acceptor的**响应**，那么它就可以生成编号为N，Value为V的**提案[N,V]**。这里的V是所有的响应中**编号最大的提案的Value**。如果所有的响应中**都没有提案**，那 么此时V就可以由Proposer**自己选择**。
   生成提案后，Proposer将该**提案**发送给**半数以上**的Acceptor集合，并期望这些Acceptor能接受该提案。我们称该请求为**Accept请求**。（注意：此时接受Accept请求的Acceptor集合**不一定**是之前响应Prepare请求的Acceptor集合）

##### Acceptor接受提案

Acceptor**可以忽略任何请求**（包括Prepare请求和Accept请求）而不用担心破坏算法的**安全性**。因此，我们这里要讨论的是什么时候Acceptor可以响应一个请求。

我们对Acceptor接受提案给出如下约束：

> P1a：一个Acceptor只要尚**未响应过**任何**编号大于N**的**Prepare请求**，那么他就可以**接受**这个**编号为N的提案**。

如果Acceptor收到一个编号为N的Prepare请求，在此之前它已经响应过编号大于N的Prepare请求。根据P1a，该Acceptor不可能接受编号为N的提案。因此，该Acceptor可以忽略编号为N的Prepare请求。当然，也可以回复一个error，让Proposer尽早知道自己的提案不会被接受。

因此，一个Acceptor**只需记住**：1. 已接受的编号最大的提案 2. 已响应的请求的最大编号。

![小优化](D:\学习\springcloud\文件\paxos\7.jpg)

##### Paxos算法描述

经过上面的推导，我们总结下Paxos算法的流程。

Paxos算法分为**两个阶段**。具体如下：

- **阶段一：**

  (a) Proposer选择一个**提案编号N**，然后向**半数以上**的Acceptor发送编号为N的**Prepare请求**。

  (b) 如果一个Acceptor收到一个编号为N的Prepare请求，且N**大于**该Acceptor已经**响应过的**所有**Prepare请求**的编号，那么它就会将它已经**接受过的编号最大的提案（如果有的话）**作为响应反馈给Proposer，同时该Acceptor承诺**不再接受**任何**编号小于N的提案**。

- **阶段二：**

  (a) 如果Proposer收到**半数以上**Acceptor对其发出的编号为N的Prepare请求的**响应**，那么它就会发送一个针对**[N,V]提案**的**Accept请求**给**半数以上**的Acceptor。注意：V就是收到的**响应**中**编号最大的提案的value**，如果响应中**不包含任何提案**，那么V就由Proposer**自己决定**。

  (b) 如果Acceptor收到一个针对编号为N的提案的Accept请求，只要该Acceptor**没有**对编号**大于N**的**Prepare请求**做出过**响应**，它就**接受该提案**。

![Paxos算法流程](D:\学习\springcloud\文件\paxos\8.jpg)

#### Learner学习被选定的value

Learner学习（获取）被选定的value有如下三种方案：

![幻灯片17.png](D:\学习\springcloud\文件\paxos\9.jpg)

#### 如何保证Paxos算法的活性

![幻灯片18.png](D:\学习\springcloud\文件\paxos\10.jpg)

通过选取**主Proposer**，就可以保证Paxos算法的活性。至此，我们得到一个**既能保证安全性，又能保证活性**的**分布式一致性算法**——**Paxos算法**。

#### 参考资料

- 论文《Paxos Made Simple》
- 论文《The Part-Time Parliament》
- 英文版维基百科的Paxos
- 中文版维基百科的Paxos
- 书籍《从Paxos到ZooKeeper》
- https://www.cnblogs.com/linbingdong/p/6253479.html

### 4.Raft协议原理详解

https://zhuanlan.zhihu.com/p/91288179



# SpringCloud Netflix 

## Spring Cloud 快速入门（一）简介、与Dubbo对比、创建基础工程

### 1. Spring Cloud 简介

#### 1.1 简介

我们从多个角度看什么是Spring Cloud：

##### 1.1.1 官网简介

![在这里插入图片描述](D:\学习\springcloud\文件\springcloud netflix 快速入门\1\1.jpg)





打开 Spring 官网 http://spring.io 首页的中部，可以看到 Spring Cloud 的简介。

【原文】Building distributed systems doesn’t need to be complex and error-prone(易错). Spring Cloud offers a simple and accessible(易接受的) programming model to the most common distributed system patterns(模式), helping developers build resilient(有弹性的), reliable(可靠的), and coordinated(协调的) applications. Spring Cloud is built on top of Spring Boot, making it easy for developers to get started and become productive quickly.

【翻译】构建分布式系统不需要复杂和容易出错。Spring Cloud 为最常见的分布式系统模式提供了一种简单且易于接受的编程模型，帮助开发人员构建有弹性的、可靠的、协调的应用程序。Spring Cloud 构建于 Spring Boot 之上，使得开发者很容易入手并快速应用于生产中。
![在这里插入图片描述](D:\学习\springcloud\文件\springcloud netflix 快速入门\1\2.jpg)



##### 1.1.2 百度百科

**Spring Cloud 是一系列框架的有序集合**。它利用 Spring Boot 的开发便利性巧妙地简化了分布式系统基础设施的开发，如**服务发现注册、配置中心、消息总线、负载均衡、断路器、数据监控**等，都可以用 Spring Boot 的开发风格做到一键启动和部署。Spring Cloud 并没有重复制造轮子，它只是将目前各家公司开发的比较成熟、经得起实际考验的服务框架组合起来，通过 Spring Boot 风格进行再封装屏蔽掉了复杂的配置和实现原理，最终给开发者提供了一套简单易懂、易部署和易维护的分布式系统开发工具包。

##### 1.1.3 总结

Spring Cloud 是什么？阿里高级框架师、Dubbo 项目的负责人刘军说，Spring Cloud 是微服务系统架构的一站式解决方案。

Spring Cloud 与 Spring Boot 是什么关系呢？Spring Boot 为 Spring Cloud 提供了代码实现环境，使用 Spring Boot将其它组件有机融合到了 Spring Cloud 的体系架构中了。所以说，**Spring Cloud 是基于 Spring Boot 的、微服务系统架构的一站式解决方案**。


#### 1.2 Spring Cloud 在线资源

Spring Cloud 官网 https://projects.spring.io/spring-cloud/
Spring Cloud 中文网 https://springcloud.cc/
Spring Cloud 中国社区 http://springcloud.cn/

#### 1.3 Spring Cloud 版本

##### 1.3.1 版本号来源

![在这里插入图片描述](D:\学习\springcloud\文件\springcloud netflix 快速入门\1\3.jpg)



Spring Cloud 的版本号并不是我们通常见的数字版本号，而是一些很奇怪的单词。这些单词均为英国伦敦地铁站的站名。同时根据字母表的顺序来对应版本时间顺序，比如：最早的 Release 版本 Angel（天使），第二个 Release 版本 Brixton（英国地名），然后是 Camden、Dalston、Edgware、Finchley（英国地名）版本、 Hoxton（英国地名），后续的快速入门篇，我们使用的都是目前 Hoxton。

除了版本号外还有一些其他的版本标记：

1. SNAPSHOP：快照版，可以使用，但其仍处理连续不断的开发改进中，不建议使用。
2. M：里程碑版。其也会标注上 PRE，preview，预览版，内测版，不建议使用。
3. RC：Release Candidate，发行候选版，主要是用于修复 BUG，一般该版本中不会再添加大的功能修改了。正式发行前的版本。
4. SR：Service Release，服务发行版，正式发行版。一般还会被标注上 GA，General Available

##### 1.3.2 Spring Cloud 与 Spring Boot 版本

某一版本的 Spring Cloud 要求必须要运行在某一特定 Spring Boot 版本下。它们的对应关系在 [Spring Cloud 官网](https://spring.io/projects/spring-cloud#overview)可以看到版本对应说明。

![image-20220121153606282](D:\学习\springcloud\文件\springcloud netflix 快速入门\1\4.jpg)



### 2. Spring Cloud 与 Dubbo之间对比

#### 2.1 Spring Cloud 与 Dubbo对比

首先给了一个常见的分布式架构图：

![在这里插入图片描述](D:\学习\springcloud\文件\springcloud netflix 快速入门\1\5.jpg)




# SpringCloud Eureka源码分析

## 杂记

### 1.jersey框架

SpringCloud用的是**jersey**框架，与SpringMVC框架不同的是SpringMVC用的是Controller作为处理器，而jersey用的是Resource

jersey与springmvc 的区别：

```java
1. jersey同样提供DI，是由glassfish hk2实现，也就是说，如果想单独使用jersey一套，需要另外学习Bean容器；

2. MVC出发点即是WEB，但jersey出发点确实RESTFull，体现点在与接口的设计方面，
如MVC返回复杂结构需要使用ModelAndView,而jersey仅仅需要返回一个流或者文件句柄；

3. jersey提供一种子资源的概念，这也是RESTFull中提倡所有url都是资源；

4. jersey直接提供application.wadl资源url说明；

5. MVC提供Session等状态管理，jersey没有，这个源自RESTFull设计无状态化；

6. Response方法支持更好返回结果，方便的返回Status，包括200，303，401，403；

7. 提供超级特别方便的方式访问RESTFull;
```

jersey常用注解解释：

```java
@Path
uri路径
定义资源的访问路径，client通过这个路径访问资源。比如：@Path("user")

@Produces
返回
指定返回MIME格式
资源按照那种数据格式返回，可取的值有：MediaType.APPLICATION_XXX。比如：@Produces(MediaType.APPLICATION_XML)

@Consumes
接收入参
接受指定的MIME格式
只有符合这个参数设置的请求再能访问到这个资源。比如@Consumes("application/x-www-form-urlencoded")

@PathParam
uri路径参数
写在方法的参数中，获得请求路径参数。比如：@PathParam("username")  String userName
```

Springcloud的InstanceResource：

![image-20220115153610539](D:\学习\springcloud\文件\数据结构\resource.jpg)



## Eureka 的数据存储结构

结构图：

<img src="D:\学习\springcloud\文件\数据结构\数据结构.png" alt="数据结构" style="zoom: 67%;" />

Eureka 的数据存储分了两层：数据存储层和缓存层。



Eureka Client 在拉取服务信息时，先从缓存层获取（相当于 Redis），如果获取不到，先把数据存储层的数据加载到缓存中（相当于 Mysql），再从缓存中获取。值得注意的是，数据存储层的数据结构是服务信息，而缓存中保存的是经过处理加工过的、可以直接传输到 Eureka Client 的数据结构。



Eureka 这样的数据结构设计是把内部的数据存储结构与对外的数据结构隔离开了，就像是我们平时在进行接口设计一样，对外输出的数据结构和数据库中的数据结构往往都是不一样的。



**数据存储层**



这里为什么说是存储层而不是持久层？因为 registry 本质上是一个双层的 ConcurrentHashMap，存储在内存中的。



- 第一层的 key 是`spring.application.name`，value 是第二层 ConcurrentHashMap；
- 第二层 ConcurrentHashMap 的 key 是服务的 InstanceId，value 是 Lease 对象；
- Lease 对象包含了服务详情和服务治理相关的属性。

**二级缓存层**

Eureka 实现了二级缓存来保存即将要对外传输的服务信息，数据结构完全相同。

- 一级缓存：`ConcurrentHashMap<Key,Value> readOnlyCacheMap`，本质上是 HashMap，无过期时间，保存服务信息的对外输出数据结构。
- 二级缓存：`Loading<Key,Value> readWriteCacheMap`，本质上是 guava 的缓存，包含失效机制，保存服务信息的对外输出数据结构。

既然是缓存，那必然要有更新机制，来保证数据的一致性。下面是缓存的更新机制：



![img](D:\学习\springcloud\文件\数据结构2.png)



更新机制包含删除和加载两个部分，上图黑色箭头表示删除缓存的动作，绿色表示加载或触发加载的动作。



**删除二级缓存：**

1. Eureka Client 发送 register、renew 和 cancel 请求并更新 registry 注册表之后，删除二级缓存；
2. Eureka Server 自身的 Evict Task 剔除服务后，删除二级缓存；
3. 二级缓存本身设置了 guava 的失效机制，隔一段时间后自己自动失效；

**加载二级缓存：**

1. Eureka Client 发送 getRegistry 请求后，如果二级缓存中没有，就触发 guava 的 load，即从 registry 中获取原始服务信息后进行处理加工，再加载到二级缓存中。
2. Eureka Server 更新一级缓存的时候，如果二级缓存没有数据，也会触发 guava 的 load。

**更新一级缓存：**

1. Eureka Server 内置了一个 TimerTask，定时将二级缓存中的数据同步到一级缓存（这个动作包括了删除和加载）。1.

## 自动配置分析

### 1.1入口

入口从starter开始：



![image-20220115154154517](D:\学习\springcloud\文件\自动配置分析\1.png)



![image-20220115154443873](D:\学习\springcloud\文件\自动配置分析\2.png)

看到pom中引入了如下依赖：

![image-20220115154601668](D:\学习\springcloud\文件\自动配置分析\3.png)



![image-20220115154647553](D:\学习\springcloud\文件\自动配置分析\4.png)

![image-20220115154738955](D:\学习\springcloud\文件\自动配置分析\5.png)



### 1.2 @EnableEurekaServer

![image-20220115155259330](C:\Users\viruser.v-desktop\AppData\Roaming\Typora\typora-user-images\image-20220115155259330.png)

我们看到这个自动配置类要起效，要求容器中要有EurekaServerMarkerConfiguration.Marker的实例，那么这个Marker在哪创建的呢？

我们知道要启动EurekaServer，要在启动类上加@EnableEurekaServer注解，看下这个注解：

```
@EnableEurekaServer   // 开启Eureka服务
@SpringBootApplication
public class ApplicationEuerkaServer8000 {

    public static void main(String[] args) {
        SpringApplication.run(ApplicationEuerkaServer8000.class, args);
    }

}

//我们看这个EnableEurekaServer注解：

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import(EurekaServerMarkerConfiguration.class)//看到导入了一个配置类
public @interface EnableEurekaServer {

}

//看这个配置类
@Configuration(proxyBeanMethods = false)
public class EurekaServerMarkerConfiguration {

	@Bean
	public Marker eurekaServerMarkerBean() {
		//看到就是在这里创建了一个Marker实例
		return new Marker();
	}
	
	class Marker {
	
	}

}
```

通过上面分析我们知道通过@EnableEurekaServer注解，会创建Marker实例，从而让EurekaServerAutoConfiguration这个自动配置类生效。



