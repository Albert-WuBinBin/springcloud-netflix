package com.wbb.entity;

import lombok.Data;

@Data
public class Depart {
    private Integer id;
    private String name;
}
