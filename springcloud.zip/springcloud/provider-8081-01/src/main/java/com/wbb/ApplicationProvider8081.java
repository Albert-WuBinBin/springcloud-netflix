package com.wbb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationProvider8081 {

    public static void main(String[] args) {
        SpringApplication.run(ApplicationProvider8081.class, args);
    }

}
