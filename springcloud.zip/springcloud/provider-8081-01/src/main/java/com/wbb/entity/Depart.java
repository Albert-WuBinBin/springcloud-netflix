package com.wbb.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Data
@Entity  // springdatajpa默认用的hibernate，可以自动建表
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler", "fieldHandler"})
// 客户端与服务器之间的数据交互，是由SpringMVC的HttpMessageConverter处理的
// 其中一个实现是处理  Jackson数据 -> 完成Java对象与JSON数据间的转换工作
// JPA的默认实现是Hibernate，而Hibernate默认对于对象的查询是基于延迟加载的
// Depart depart = service.findById(5);   这里的depart实际是一个javasist动态代理对象
// String name = depart.getName();
// 对于HttpMessageConverter，它拿到对象后会立即转成json，这个时候对象中有些数据是空的会报错
// 基于这种情况我们需要忽略掉一些属性就不会报错了
public class Depart {
    @Id  // 表示当前属性为自动建的表的主键
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // 主键自动递增
    private Integer id;
    private String name;
}
